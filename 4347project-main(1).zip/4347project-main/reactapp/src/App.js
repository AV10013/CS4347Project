// App.js

import React from 'react';
import BookSearch from './components/BookSearch';
import BookLoans from './components/BookLoans';
import BorrowerManagement from './components/BorrowerManagement';
import Fines from './components/Fines';

function App() {
  return (
    <div>
      <h1>Library Management System</h1>
      <BookSearch />
      <BookLoans />
      <BorrowerManagement />
      <Fines />
    </div>
  );
}

export default App;
