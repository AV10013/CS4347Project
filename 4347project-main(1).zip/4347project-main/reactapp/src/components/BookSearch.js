import React, { useState } from 'react';

function BookSearch() {
  const [searchText, setSearchText] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [error, setError] = useState(null);

  const handleSearch = () => {
    setError(null); // Clear any previous errors
    fetch(`http://localhost:3001/api/search?query=${searchText}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => setSearchResults(data))
      .catch((error) => {
        setError(error.message); // Set an error message in state
        console.error('Fetch Error:', error);
      });
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Search for books..."
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>

      {error && <p>Error: {error}</p>}

      <div>
      {searchResults.map((result) => (
  <div key={result.ISBN}>
    <p>ISBN: {result.ISBN}</p>
    <p>Title: {result.TITLE}</p> {/* Change this line */}
    <p>Authors: {result.Authors}</p>
    <p>Availability: {result.Availability}</p>
  </div>
))}
      </div>
    </div>
  );
}

export default BookSearch;
