// BookLoans.js

import React, { useState } from 'react';
//main function
function BookLoans() {
  const [isbn, setIsbn] = useState('');
  const [cardNo, setCardNo] = useState('');
  const [checkoutError, setCheckoutError] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [CheckInMessge, setCheckInMessage] = useState('');
  const [CheckMessage, setCheckMessage] = useState('');
  //handles checkout by using a fetch route with the isbn and cardNo
  //worked without "METHOD" in the function for fetch for some reason
  const handleCheckout = () => {
    setCheckoutError(null);
    setCheckMessage(null);
    setCheckInMessage(null);
    fetch(`http://localhost:3001/api/search/isbn?isbn=${isbn}&cardNo=${cardNo}`)
      .then((response) => {
        if (!response.ok) { 
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        setSearchResults(data)
        setCheckMessage("Thank you for checking out your book, please remember that your books are due back in 14 days.")
      })
      .catch((error) => {
        setCheckoutError("We're sorry, it appears that you have either 3 books checked out or the book is currently not available, please check in one or more of your checked out books or wait for the checked out book to checked in, Thank you.")
        console.error("checkout error", error);
      });
  };

  //handles check in by using a fetch route with isbn 
  const handleCheckin = () => {
    setCheckoutError(null);
    setCheckMessage(null);
    setCheckInMessage(null);
    fetch(`http://localhost:3001/api/book-loans/${isbn}`,{
      method: 'DELETE',
    })
    .then(response => {
      if(!response.ok) {
        throw new Error('response was not ok');
      }
      return response.json();
    })
    .then(data => {
      console.log(data.message);
      setCheckInMessage("Thank you for checking in your Book")
    })
    .catch(error => {
      console.error("error", error);
    })
  };

  //return HTML code, which has the inputs, the buttons, and data for return from sql
  return (
    <div>
      <input
        type="text"
        id = "ISBN_VALUE"
        placeholder="Enter ISBN..."
        value={isbn}
        onChange={(e) => setIsbn(e.target.value)}
      />
      <input
        type="text"
        placeholder="Enter Card Number..."
        value={cardNo}
        onChange={(e) => setCardNo(e.target.value)}
      />
      <button onClick={handleCheckout}>Checkout</button>
      <button onClick={handleCheckin}>Checkin</button>
      {checkoutError && <p>ERROR: {checkoutError}</p>}
      {CheckMessage && (
        <p>{CheckMessage}</p>
      )}
      {CheckInMessge && (
        <p>{CheckInMessge}</p>
      )}   
      {searchResults.book && (
        <>
          <p>ISBN: {searchResults.book[0]?.ISBN}</p>
          <p>Title: {searchResults.book[0]?.TITLE}</p>
          <p>Authors: {searchResults.book[0]?.Authors}</p>
          <p>Availability: {searchResults.book[0]?.Availability}</p> 
        </>
      )}
    {searchResults.borrower && (
      <>
      <br></br>
      <br></br>
      <p>BORROWER DETAILS: </p>
      <p>Name: {searchResults.borrower[0]?.BNAME}</p>
        <p>CARD ID: {searchResults.borrower[0]?.CARD_ID}</p>
        <p>Address: {searchResults.borrower[0]?.ADDRESS}</p>
        <p>Phone: {searchResults.borrower[0]?.PHONE}</p>
      </>
    )}

  </div>
      )
      }

export default BookLoans;