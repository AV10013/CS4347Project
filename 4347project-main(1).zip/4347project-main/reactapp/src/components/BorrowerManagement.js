// BorrowerManagement.js

import React, { useState } from 'react';

function BorrowerManagement() {
  const [name, setName] = useState('');
  const [ssn, setSsn] = useState('');
  const [address, setAddress] = useState('');
  const [createError, setCreateError] = useState('');

  const handleCreateBorrower = () => {
    const requestData = {
      BNAME: name,      // Ensure property name is BNAME
      SSN: ssn,         // Ensure property name is SSN
      ADDRESS: address, // Ensure property name is ADDRESS
    };

    fetch('http://localhost:3001/api/addBorrower', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
    })
      .then(response => response.json())
      .then(data => {
        // Handle the response data
        console.log(data);

        // Check for errors in the response
        if (data.error) {
          setCreateError(data.error); // Set the error message
        } else {
          // Reset error state if successful
          setCreateError('');
        }
      })
      .catch(error => {
        // Handle errors
        console.error('Error:', error);
      });
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Enter Name..."
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        type="text"
        placeholder="Enter SSN..."
        value={ssn}
        onChange={(e) => setSsn(e.target.value)}
      />
      <input
        type="text"
        placeholder="Enter Address..."
        value={address}
        onChange={(e) => setAddress(e.target.value)}
      />
      <button onClick={handleCreateBorrower}>Create Borrower</button>

      {/* Display create borrower related information and error messages */}
      {createError && <p style={{ color: 'red' }}>{createError}</p>}
    </div>
  );
}

export default BorrowerManagement;
