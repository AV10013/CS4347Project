const express = require('express');
const sqlite3 = require('sqlite3');
const path = require('path');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 3001; // Changed port to 3001

app.use(cors());

app.use(express.json());


const db = new sqlite3.Database(path.join(__dirname, 'LIBRARY.db'), (err) => {
  if (err) {
    console.error('Error opening database', err.message);
  }
});


app.use(express.static(path.join(__dirname, 'build')));

//SEARCH FUNCTION
app.get('/api/search', (req, res) => {
  const searchQuery = req.query.query;

  const sql = `
  SELECT B.ISBN, B.Title, GROUP_CONCAT(A.Name, ', ') AS Authors
  FROM BOOK AS B
  JOIN BOOK_AUTHORS AS BA ON B.ISBN = BA.ISBN
  JOIN AUTHORS AS A ON BA.AUTHOR_ID = A.AUTHOR_ID
  WHERE B.Title LIKE ? OR A.Name LIKE ?
  GROUP BY B.ISBN  
`;

  const searchPattern = `%${searchQuery}%`;

  db.all(sql, [searchPattern, searchPattern], (err, rows) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    console.log(rows); // Add this line to log the response data
    res.json(rows); // Existing line to send response
  });
});

//ADD BORROWER FUNCTION
app.post('/api/addBorrower', async (req, res) => {
  const { BNAME, SSN, ADDRESS } = req.body;

  try {
    const checkExistingBorrowerSql = 'SELECT COUNT(*) AS count FROM BORROWER WHERE SSN = ?';
    const { count } = await getQueryResult(checkExistingBorrowerSql, [SSN]);

    if (count > 0) {
      // A borrower with the same SSN already exists
      return res.status(400).json({ error: 'A borrower with this SSN already exists.' });
    }

    // Continue if SSN is unique
    const getLastCardIdSql = 'SELECT MAX(CAST(SUBSTR(CARD_ID, 3) AS INTEGER)) AS MAX_ID FROM BORROWER';
    const { MAX_ID } = await getQueryResult(getLastCardIdSql);

    if (MAX_ID === null) {
      // If there are no existing borrowers, start from ID000001
      var nextCardId = 'ID000001';
    } else {
      // Increment the last used CARD_ID
      var nextCardId = 'ID' + ('000000' + (MAX_ID + 1)).slice(-6);
    }

    // Insert the new borrower
    const insertBorrowerSql = 'INSERT INTO BORROWER (SSN, BNAME, ADDRESS, CARD_ID, PHONE) VALUES (?, ?, ?, ?, ?)';
    // Generate a random PHONE number
    const PHONE = generatePhoneNumber();

    db.run(
      insertBorrowerSql,
      [SSN, BNAME, ADDRESS, nextCardId, PHONE],
      function (err) {
        if (err) {
          // Check if the SSN already exists
          if (err.message.includes('UNIQUE constraint failed')) {
            return res.status(400).json({ error: 'A borrower with this SSN already exists.' });
          }

          console.error('Error inserting borrower:', err);
          return res.status(500).json({ error: 'Error inserting borrower into the database' });
        }

        res.json({ success: true, cardId: nextCardId });
      }
    );

  } catch (error) {
    console.error('Error handling request:', error);
    return res.status(500).json({ error: 'An error occurred while processing the request.' });
  }
});

// Execute SQL query and return the result
function getQueryResult(sql) {
  return new Promise((resolve, reject) => {
    db.get(sql, (err, row) => {
      if (err) {
        reject(err);
      } else {
        resolve(row);
      }
    });
  });
}

// Function to generate a formatted PHONE number
function generatePhoneNumber() {
  // Assume it's a random 10-digit number
  const rawPhoneNumber = Math.floor(1000000000 + Math.random() * 9000000000).toString();

  // Format the phone number
  const formattedPhoneNumber =
    '(' +
    rawPhoneNumber.substring(0, 3) +
    ') ' +
    rawPhoneNumber.substring(3, 6) +
    '-' +
    rawPhoneNumber.substring(6, 10);

  return formattedPhoneNumber;
}

//ISBN CHECKOUT FUNCTION
app.get('/api/search/isbn', (req,res) => {
  //this part assigns the variables
  const isbn = req.query.isbn;
  const cardNo = req.query.cardNo;

  //this part has 2 sql functions
  const bookSql = `
    SELECT B.ISBN, B.Title, B.Availability, GROUP_CONCAT(A.Name, ', ') AS Authors
    FROM BOOK AS B
    JOIN BOOK_AUTHORS AS BA ON B.ISBN = BA.ISBN
    JOIN AUTHORS AS A ON BA.AUTHOR_ID = A.AUTHOR_ID
    WHERE B.ISBN = ?
    GROUP BY B.ISBN
  `;

  
  const borrowerSql = `
    SELECT CARD_ID, BNAME, ADDRESS, PHONE
    FROM BORROWER
    WHERE CARD_ID = ?
  `;

  //this part gets data on book
  db.all(bookSql, [isbn], (bookErr, BookRows) => {
    if (bookErr) {
      console.error('Error querying BOOK table:', bookErr);
      return res.status(500).json({ error: 'Database error' });
    }
  
  //gets data on borrower
  db.all(borrowerSql, [cardNo], (borrowerErr, BorrowerRows) => {
    if (borrowerErr) {
      console.error('Error querying BORROWER table:', borrowerErr);
      return res.status(500).json({ error: 'Database error' });
      }
    
    //not needed anymore
    const BookInfo = BookRows[0];
    const BorrowerInfo = BorrowerRows[0];

    //sql for checking if person has more than 3 loans
    const check = 
      `SELECT COUNT(*) AS count
      FROM BOOK_LOANS
      WHERE CARD_ID = ?;
      `
  db.get(check, [cardNo], (countErr,countRows) => {
    if (countErr) {
      console.error("Error", consoleErr)
      return res.status(500).json({error : "database error"});
       }

  const card = countRows.count;

  //sql for availability check
  const AvailabilityCheck =  `SELECT Availability
    FROM BOOK
  WHERE ISBN = ?;`
  
  db.get(AvailabilityCheck, [isbn], (availabilityErr, availabilityResult) => {
    if (availabilityErr) {
      console.error('Error checking availability:', availabilityErr);
      return res.status(500).json({ error: 'Database error' });
    }

  //if statement will not normally let person checkout if books are more than 3 or if book is not available according to database
  if (card >= 3 || availabilityResult.Availability === 0) {
    console.error("3 ACTIVE CHECKOUTS OR BOOK NOT AVAILABLE FOR NOW")
    return res.status(500).json({error: "3 ACTIVE CHECKOUTS OR BOOK NOT AVAILABLE FOR NOW"})
  }
  else {
    //sql for insert books and change availability function
    const insertBookLoanSql = `
        INSERT INTO BOOK_LOANS (ISBN, CARD_ID, DATE_OUT, DATE_IN, DUE_DATE)
        VALUES (?, ?, DATE('now'), DATE('now', '+14 days'), DATE('now', '+14 days'));
      `;

    const changeAvailability = `UPDATE BOOK
        SET Availability = 0
        WHERE ISBN = ?;
        `

    
      db.run(insertBookLoanSql,
        [isbn, cardNo],
        function (insertErr) {
          if (insertErr) {
            console.error('Error inserting into BOOK_LOANS table:', insertErr);
            return res.status(500).json({ error: 'Database error' });
          }
        });

      db.run(changeAvailability,[BookInfo.ISBN])
      
  }
      //keep track of last inserted loan ID
      const lastInsertedLoanId = this.lastID;
      //save result
      const result = {
        book: BookRows,
        borrower: BorrowerRows,
        loanId: lastInsertedLoanId,
      };
  
      console.log(result);
      //res result
      res.json(result);
   });

  });
});
  });
});

//ISBN CHECKIN FUNCTION
app.delete('/api/book-loans/:isbn', (req, res) => {
  //set variable 
  const isbn = req.params.isbn;
  //sql for removing the book from BOOK_LOANS (this represents the book being checked back)
  const removeBookLoanSql = `
    DELETE FROM BOOK_LOANS
    WHERE ISBN = ?;
  `;
  //sql for availability being set to "true" to let the system know that the book can be checked again
  const setAvailabilitySql = `
    UPDATE BOOK
    SET Availability = 1
    WHERE ISBN = ?;
  `;

  //read somewhere that this is good practice (db.serialize())
  db.serialize(() => {
    db.run(removeBookLoanSql, [isbn], (removeErr) => {
      if (removeErr) {
        console.error('Error removing book loan:', removeErr);
        return res.status(500).json({ error: 'Database error' });
      }

      db.run(setAvailabilitySql, [isbn], (updateErr) => {
        if (updateErr) {
          console.error('Error updating availability:', updateErr);
          return res.status(500).json({ error: 'Database error' });
        }

        console.log('Book loan removed and availability updated.');
        res.status(200).json({ message: 'Book loan removed and availability updated.' });
      });
    });
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
