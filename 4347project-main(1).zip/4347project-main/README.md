# 4347project
4347 project

You need to separatly start the back end and the front end to get it to run:

![image](https://github.com/enaye/4347project/assets/47686481/0fba9278-4d40-433b-aa8f-55f3003baa5d)
![image](https://github.com/enaye/4347project/assets/47686481/2e32cc5a-5961-4ead-84e3-ab5fd7be4c95)

![image](https://github.com/enaye/4347project/assets/47686481/73c27e86-a433-4edc-9b2b-911a59f546e2)

